-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 01, 2023 at 05:32 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_attendance_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `ID` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`ID`, `fname`, `lname`, `email`, `password`) VALUES
(3, 'sanket', 'bhoir', 'admin@gmail.com', '021db155bb0ebc5c3adb2975339bc647');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `ID` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `course` varchar(255) NOT NULL,
  `year` varchar(20) NOT NULL,
  `date` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`ID`, `fname`, `lname`, `course`, `year`, `date`, `status`) VALUES
(25, 'sachin', 'yadav', 'bca', 'fy', '27-08-2023', 'present'),
(26, 'sumit', 'powar', 'bca', 'fy', '27-08-2023', 'present'),
(22, 'uday', 'harad', 'bca', 'fy', '27-08-2023', 'present'),
(30, 'ravi', 'singh', 'bca', 'sy', '27-08-2023', 'absent'),
(29, 'suresh', 'yadav', 'bca', 'sy', '27-08-2023', 'present'),
(25, 'sachin', 'yadav', 'bca', 'fy', '28-08-2023', 'present'),
(26, 'sumit', 'powar', 'bca', 'fy', '28-08-2023', 'present'),
(22, 'uday', 'harad', 'bca', 'fy', '28-08-2023', 'present'),
(25, 'sachin', 'yadav', 'bca', 'fy', '29-08-2023', 'present'),
(26, 'sumit', 'powar', 'bca', 'fy', '29-08-2023', 'present'),
(22, 'uday', 'harad', 'bca', 'fy', '29-08-2023', 'present'),
(25, 'sachin', 'yadav', 'bca', 'fy', '30-08-2023', 'present'),
(26, 'sumit', 'powar', 'bca', 'fy', '30-08-2023', 'present'),
(22, 'uday', 'harad', 'bca', 'fy', '30-08-2023', 'present'),
(25, 'sachin', 'yadav', 'bca', 'fy', '02-09-2023', 'present'),
(26, 'sumit', 'powar', 'bca', 'fy', '02-09-2023', 'present'),
(22, 'uday', 'harad', 'bca', 'fy', '02-09-2023', 'present'),
(25, 'sachin', 'yadav', 'bca', 'fy', '13-09-2023', 'present'),
(26, 'sumit', 'powar', 'bca', 'fy', '13-09-2023', 'present'),
(22, 'uday', 'harad', 'bca', 'fy', '13-09-2023', 'present'),
(25, 'sachin', 'yadav', 'bca', 'fy', '14-09-2023', 'absent'),
(26, 'sumit', 'powar', 'bca', 'fy', '14-09-2023', 'present'),
(22, 'uday', 'harad', 'bca', 'fy', '14-09-2023', 'present'),
(25, 'sachin', 'yadav', 'bca', 'fy', '30-10-2023', 'absent'),
(26, 'sumit', 'powar', 'bca', 'fy', '30-10-2023', 'present'),
(22, 'uday', 'harad', 'bca', 'fy', '30-10-2023', 'present'),
(24, 'sanket', 'ghagare', 'bscit', 'ty', '30-10-2023', 'present'),
(34, 'sumit', 'gawade', 'bca', 'sy', '01-11-2023', 'present'),
(23, 'avi', 'lakade', 'mca', 'fy', '01-11-2023', 'present'),
(32, 'ravi', 'singh', 'mca', 'fy', '01-11-2023', 'present'),
(25, 'sachin', 'yadav', 'bca', 'fy', '01-11-2023', 'absent'),
(26, 'sumit', 'powar', 'bca', 'fy', '01-11-2023', 'present'),
(22, 'uday', 'harad', 'bca', 'fy', '01-11-2023', 'absent'),
(24, 'sanket', 'ghagare', 'bscit', 'ty', '01-11-2023', 'present');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `no` int(11) NOT NULL,
  `course_name` varchar(255) DEFAULT NULL,
  `duration` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`no`, `course_name`, `duration`) VALUES
(13, 'bca', '3 year'),
(14, 'mscit', '3 year'),
(15, 'bba', '3 year'),
(24, 'bscit', '3 year'),
(25, 'mca', '2 year');

-- --------------------------------------------------------

--
-- Table structure for table `course_year`
--

CREATE TABLE `course_year` (
  `num` int(11) NOT NULL,
  `year` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course_year`
--

INSERT INTO `course_year` (`num`, `year`) VALUES
(2, 'fy'),
(13, 'sy'),
(15, 'ty');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `ID` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `course` varchar(50) NOT NULL,
  `year` varchar(50) NOT NULL,
  `city` varchar(20) NOT NULL,
  `phone` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`ID`, `fname`, `lname`, `email`, `password`, `course`, `year`, `city`, `phone`) VALUES
(22, 'uday', 'harad', 'uday@gmail.com', 'b0931392878fe70bf92e4f699dcf9213', 'bca', 'fy', 'thane', 6545664),
(23, 'avi', 'lakade', 'avi@gmail.coma', 'a753c45c8de9e393c09464b8d8b8447b', 'mca', 'fy', 'shahapur', 2147483647),
(24, 'sanket', 'ghagare', 'sanket@gmail.com', 'a73ec72702166f7f685e536a910d54d9', 'bscit', 'ty', 'bhiwandi', 2147483647),
(25, 'sachin', 'yadav', 'sachin@gmail.com', '9c182baae5f199a97e907712e0a60141', 'bca', 'fy', 'kalwa', 2147483647),
(26, 'sumit', 'powar', 'sumit@gmail.com', 'f9598c2dd34ad2c3f75c05278b6f442f', 'bca', 'fy', 'kalyan', 2147483647),
(32, 'ravi', 'singh', 'ravi@gmail.com', '1790f19d6edb09a7a94870e99c7b0689', 'mca', 'fy', 'Kalwa', 2147483647),
(33, 'suresh', 'yadav', 'suresh@gmail.com', '3dc43a75d3a9eb9829f22b569d7a8a9b', 'bba', 'fy', 'thane', 2147483647),
(34, 'sumit', 'gawade', 'sumitGawade@gmail.com', '070c46ae1c20ded0f348e3e282e9c35a', 'bca', 'sy', 'dombivali', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `subject_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `course_name`, `subject_name`) VALUES
(5, 'bca', 'dsa'),
(7, 'mca', 'dsa'),
(8, 'bscit', 'cc'),
(9, 'bca', 'cc'),
(10, 'bca', 'php'),
(11, 'bca', 'asp.net');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `ID` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `class` varchar(30) NOT NULL,
  `year` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`ID`, `fname`, `lname`, `email`, `password`, `class`, `year`) VALUES
(5, 'uday', 'harad', 'uday@gmail.com', 'b0931392878fe70bf92e4f699dcf9213', 'bca', 'fy'),
(6, 'deepa', 'mam', 'deepa@gmail.com', '593a721839c7356f63243febda99cc33', 'bca', 'sy'),
(9, 'dipak', 'sir', 'dipak@gmail.com', 'b4d0a7fd5e612fc3a84a051d301ec30a', 'mca', 'fy'),
(11, 'sarika', 'mam', 'sarika@gmail.com', 'c973edad04c715959c7a76a9e58ee33d', 'bscit', 'fy'),
(12, 'pradnya', 'mam', 'pradnya@gmail.com', '37dad9fe03def0560b8a4b24943b49b1', 'bscit', 'ty');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `course_year`
--
ALTER TABLE `course_year`
  ADD PRIMARY KEY (`num`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `course_year`
--
ALTER TABLE `course_year`
  MODIFY `num` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
