<?php 
include '../include/dbcon.php';
include '../include/session.php';
error_reporting(0);



//-----Delete----//
if(isset($_GET['id']) && isset($_GET['action']) && $_GET['action'] == 'delete' )
{
       $id = $_GET['id'];
        $query = "DELETE FROM teacher WHERE ID = '$id'";
        mysqli_query($conn,$query);
        if ($query) {
             
          echo "<script type = \"text/javascript\">
          window.location = (\"teacher.php\")
          </script>"; 
          // echo "<div class='alert alert-success text-center'>Student Record deleted successfully.!</div>";
      }
      else
      {
          echo "<div class='alert alert-danger' style='margin-right:700px;'>An error Occurred!</div>";
      }
}

//----Edit-----//

if(isset($_GET['id']) && isset($_GET['action']) && $_GET['action'] == 'edit' )
{
  $id = $_GET['id'];
    $query=mysqli_query($conn,"select * from teacher where id ='$id'");
        $row=mysqli_fetch_array($query);
        
        if(isset($_POST['update'])){
    
          $fname = $_POST['fname'];
          $lname = $_POST['lname'];
          $email = $_POST['email'];
          $pass = md5($_POST['password']);
          $class = $_POST['class'];
          $year = $_POST['year'];

          
          $check = mysqli_query($conn,"select * from teacher where class='$class' AND year='$year' AND NOT ID='$id'");
          
          if ($check->num_rows >0) {
            echo "<div class='alert alert-danger' style='margin-right:700px;'>This class is already taken!</div>";
            
          }
          else
          {
              $query=mysqli_query($conn,"update teacher set fname='$fname', lname='$lname', email='$email', password='$pass',class='$class', year='$year' where id='$id'");
             
             echo "<script>alert('Data updated successfully.')</script>";

              echo "<script type = \"text/javascript\">
              window.location = (\"teacher.php\")
              </script>"; 
          
         }
     }

} 


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin : Add Teacher</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    
<?php include '..\include\header.php'; ?>


 <div class="cotainer p-5">
<form  method="post" class="row g-3" autocomplete="off">
  <div class="col-md-6">
    <label for="inputName" class="form-label">First Name</label>
    <input type="text" class="form-control text-capitalize" value="<?php if(isset($_GET['id'])){echo $row['fname'];}  ?>" id="inputName" name="fname" autocomplete="off" required>
  </div>
  <div class="col-md-6">
    <label for="inputName" class="form-label">Last Name</label>
    <input type="text" class="form-control text-capitalize" value="<?php if(isset($_GET['id'])){echo $row['lname'];}  ?>" id="inputName" name="lname" autocomplete="off" required>
  </div>
  <div class="col-md-6">
    <label for="inputEmail4" class="form-label">Email</label>
    <input type="email" class="form-control" value="<?php if(isset($_GET['id'])){echo $row['email'];}  ?>" id="inputEmail4" name="email" required>
  </div>
  <div class="col-md-6">
    <label for="inputPassword4" class="form-label">Password</label>
    <input type="password" class="form-control" value="<?php if(isset($_GET['id'])){echo $row['password'];}  ?>" id="inputPassword4" name="password" required>
  </div>

  <div class="col-md-6">
    <select required name="class" class="w-50 p-2 text-uppercase"> 
      <option value="">Select class...</option>
      <?php
         $q = "select * from course";
         $r = $conn->query($q);
         if($r->num_rows > 0)
         {
            while($row = $r->fetch_assoc())
            {
              echo "<option value='".$row['course_name']."'>".$row['course_name']."</option>";
            }
         }
      ?>
    </select>
  </div>



  <div class="col-md-6">
    <select required name="year" class="w-50 p-2 text-uppercase"> 
      <option value="">Select class year...</option>
      <?php
         $q = "select * from course_year";
         $r = $conn->query($q);
         if($r->num_rows > 0)
         {
            while($row = $r->fetch_assoc())
            {
              echo "<option value='".$row['year']."'>".$row['year']."</option>";
            }
         }
      ?>
    </select>
  </div>
 
  <?php
  if (isset($id))
  {
    ?>
       <div class="col-12 text-center my-5">
       <button type="submit" name="update" class="btn btn-warning  btn-lg col-4 col-xs-4">Update</button>
       </div>
       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <?php
  } else {           
    ?>  
        <div class="col-12 text-center my-5">
        <button type="submit" name="sbmt" class="btn btn-primary  btn-lg col-4 col-xs-4">Add Teacher</button>
        </div>
    <?php
     }         
     ?>

</form>
</div>

<?php
   if($conn)
   {
    if(isset($_POST['sbmt']))
    {
                 $fname = $_POST['fname'];
                 $lname = $_POST['lname'];
                 $email = $_POST['email'];
                 $pass = md5($_POST['password']);
                 $class = $_POST['class'];
                 $year = $_POST['year'];

                 //queries
                 $q = "INSERT INTO `teacher`(`fname`, `lname`, `email`, `password`, `class`, `year`) VALUES ('$fname','$lname','$email','$pass','$class','$year')";
                 $checkPass = "select * from teacher where password='$pass'";
                 $checkEmail = "select * from teacher where email='$email'";
                 $checkClass = "select * from teacher where class = '$class' AND year= '$year'";

                 $p = mysqli_query($conn,$checkPass);
                 $e = mysqli_query($conn,$checkEmail);
                 $c = mysqli_query($conn,$checkClass);
                 
                 if(mysqli_num_rows($c)>0)
                 {
                  echo "<div class='alert alert-danger text-center  w-50 m-auto' role='alert'>
                  This class co-ordinator is already present!
                 </div>";
                 }
                 else if(mysqli_num_rows($e)>0)
                 {                  
                  echo "<div class='alert alert-danger text-center w-50 m-auto' role='alert'>
                           Email is already taken! <br> Try another one...
                          </div>";
                 }else if(mysqli_num_rows($p)>0)
                 {
                  echo "<div class='alert alert-danger text-center  w-50 m-auto' role='alert'>
                  Password is already taken! <br> Try another password...
                 </div>";
                 }
                 else{
                   if(mysqli_query($conn,$q))
                   {

                     echo "<div class='alert alert-success text-center  w-50 m-auto' role='alert'>
                     Data is stored successfully!
                   </div>";
                   }else{

                    echo "<div class='alert alert-danger text-center  w-50 m-auto' role='alert'>
                    Data is not stored!
                  </div>";
                   }
                 }

          }

   }else{
    echo "<script>alert('Database is not connected')</script>";
   }
   ?>


    <!-- Table Data -->
   <div class="container mt-5">
<table class="table table-bordered border-dark">
<thead>
    <tr class=" text-center">
      <th scope="col">No.</th>
      <th scope="col">Teacher Name</th>
      <th scope="col">Class</th>
      <th scope="col">Year</th>
      <th scope="col">Password</th>
      <th scope="col">Edit</th>
      <th scope="col">Delete</th>
    </tr>
  </thead>
  <tbody>



   <?php

      // delete course row from table
      if (isset($_POST['delete'])) {
        $courseToDelete = $_POST['delete'];
        $query = "DELETE FROM teacher WHERE `ID` = '$courseToDelete'";
        mysqli_query($conn,$query);
       }


      // Table row
       $q = "select * from teacher";
       $r = mysqli_query($conn,$q);

       if(mysqli_num_rows($r)>0)
       {
          $no = 1;
        while($row = mysqli_fetch_assoc($r))
        {
           $pass = $row['password'];
          echo "<tr class='text-center'>";
          echo "<td>$no</td>";
          echo "<td class='text-uppercase'>" . $row['fname']."  " .$row['lname'] . "</td>";
          echo "<td class='text-uppercase'>" . $row['class'] . "</td>";
          echo "<td class='text-uppercase'>" . $row['year'] . "</td>";
          echo  "<td><a href='https://md5.gromweb.com/?md5=$pass' target='blank'><i class='fa-solid fa-eye-slash'></i></a></td>";
          echo  "<td><a href='?action=edit&id=".$row['ID']."'><i class='fas fa-fw fa-edit'></i></a></td>";
          echo  "<td><a href='?action=delete&id=".$row['ID']."'><i class='fas fa-fw fa-trash'></i></a></td>";  
          echo "</tr>";        
          $no +=1;  
         }

       }else{   
        echo "<p class='text-danger'>No record found*</p>";
      }        

   ?>

  </tbody>
</table>
</div>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
   
</body>
</html>