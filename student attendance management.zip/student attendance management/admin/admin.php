<?php 
include '../include/dbcon.php';
include '../include/session.php';
error_reporting(0);
// print_r($_SESSION);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin : Home page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      /* user-select: none; */
    }

    h1 {
      color: black;
      font-family: Georgia;
    }

    .box {
      border-radius: 5px;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5);
    }
  </style>
</head>

<body>


  <?php include '..\include\header.php';?>

 

<!-- Home Info -->
  <div class="main row m-5 p-5">
    <div class="box container col-lg-3 col-md-3 col-xs-6 mb-5 bg-secondary">
      <div class="text-center p-5">
        <?php 
            $t = mysqli_query($conn, "select * from teacher");
            $tRows = mysqli_num_rows($t);
            echo "<h1>$tRows</h1>";
        ?>

        <h1><i class="fas fa-chalkboard-teacher"></i>Teacher</h1>
      </div>
    </div>

    <div class="box container col-lg-3 col-md-3 col-xs-6 mb-5 bg-secondary">
      <div class="text-center p-5">
        <?php 
            $s = mysqli_query($conn, "select * from student");
            $sRows = mysqli_num_rows($s);
            echo "<h1>$sRows</h1>";
        ?>
        <h1>Student</h1>
      </div>
    </div>

    <div class="box container col-lg-3 col-md-3 col-xs-6 mb-5 bg-secondary ">
      <div class="text-center p-5">
        <?php 
            $c = mysqli_query($conn, "select * from course");
            $cRows = mysqli_num_rows($c);
            echo "<h1>$cRows</h1>";
        ?>
        <h1>Course</h1>
      </div>
    </div>
  </div>



  
  <!-- change email and password  -->
  <?php
  
    if (isset($_POST['submit'])) 
    {

      if($_POST['email'] && $_POST['password'] && $_POST['conPassword'])
      {
        $email = $_POST['email'];
        $pass = md5($_POST['password']);
        $cpass = md5($_POST['conPassword']);
        $q = "UPDATE `admin` SET `email`='$email',`password`='$pass'";
        if ($pass === $cpass) 
        {
                  if(mysqli_query($conn,$q))
                  {
                     echo "<script>alert('Email & Password is changed.')</script>";
                     header("Location: http://localhost/php/student%20attendance%20management/index.php");
                  }else{
                    echo "<script>alert('Email & Password is not changed.')</script>";
                  }
        } else {
          echo "<script>alert('Passwords not matched.')</script>";
        }
      }
 
    }
  
  ?>



  <div class="container mt-3 text-center">
    <p>Click on the button to change Email and password of Admin.</p>

    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal">
      Change
    </button>
  </div>

  <!-- The Modal -->
  <div class="modal" id="myModal">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Admin</h4>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
          <form method="post">
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label">New Email address</label>
              <input required type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email">
            </div>
            <div class="mb-3">
              <label for="exampleInputPassword1" class="form-label">New Password</label>
              <input required type="password" class="form-control" id="exampleInputPassword1" name="password">
            </div>
            <div class="mb-3">
              <label for="exampleInputPassword1" class="form-label">Confirm Password</label>
              <input required type="password" class="form-control" id="exampleInputPassword1" name="conPassword">
              <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
            </div>
            <button type="submit" class="btn btn-primary" name="submit">Submit</button>
          </form>
        </div>

        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
        </div>

      </div>
    </div>
  </div>





  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
  
</body>
</html>