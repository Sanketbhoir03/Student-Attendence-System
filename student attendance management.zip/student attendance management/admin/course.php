<?php 
include '../include/dbcon.php';
include '../include/session.php';
error_reporting(0);


//-----Delete----//
if(isset($_GET['course_name']) && isset($_GET['action']) && $_GET['action'] == 'delete' )
{
    $courseToDelete = $_GET['course_name'];
        $query = "DELETE FROM course WHERE course_name = '$courseToDelete'";
        mysqli_query($conn,$query);
        if ($query) {
             
          echo "<script type = \"text/javascript\">
          window.location = (\"course.php\")
          </script>"; 
      }
      else
      {
          echo "<div class='alert alert-danger' style='margin-right:700px;'>An error Occurred!</div>";
      }
}

//----Edit-----//

if(isset($_GET['course_name']) && isset($_GET['action']) && $_GET['action'] == 'edit' )
{
  $edit = $_GET['course_name'];
    $query=mysqli_query($conn,"select * from course where course_name ='$edit'");
        $row=mysqli_fetch_array($query);



        
        if(isset($_POST['update'])){
    
          $courseName=$_POST['course'];
          $duration=$_POST['years'];

          $check = "select * from course where course_name = '$courseName' && duration = '$duration'";
          $r = $conn->query($check);
         
          if($r->num_rows > 0)
          {
            echo "<div class='alert alert-danger' role='alert'>
            course is already present!
            </div>";    
        
          }else{
             
            $query=mysqli_query($conn,"update course set course_name='$courseName', duration='$duration' where course_name='$edit'");
           }


         if ($query) {
             
             echo "<script type = \"text/javascript\">
             window.location = (\"course.php\")
             </script>"; 
         }
         else
         {
             $statusMsg = "<div class='alert alert-danger' style='margin-right:700px;'>An error Occurred!</div>";
         }
     }

}

?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin : Add Course</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />


</head>
<body>
<?php include '..\include\header.php'; ?>


<div class="cotainer p-5">
<form method="post" class="row g-3" autocomplete="off">
  <div class="col-md-12">
    <label for="inputName" class="form-label">Course Name</label>
    <input type="text" class="form-control text-capitalize" value="<?php if(isset($_GET['course_name'])){echo $row['course_name'];}  ?>" id="inputName" name="course"  required>   
  </div>                                                                                              
  <div class="col-md-12">
    <label for="inputName" class="form-label">Duration</label>
    <input type="text" class="form-control" value="<?php if(isset($_GET['course_name'])){echo $row['duration'];} ?>"  id="inputName" name="years"  required>
  </div>

 
  <!-- <div class="col-12 text-center my-5">
    <button type="submit" class="btn btn-primary btn-lg w-25" name="sbmt">Add Course</button>
  </div> -->

        <?php


                    if (isset($edit))
                    {
                    ?>
                  <div class="col-12 text-center my-5">
                    <button type="submit" name="update" class="btn btn-warning  btn-lg w-25">Update</button>
                    </div>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <?php
                    } else {           
                    ?>  
                  <div class="col-12 text-center my-5">
                    <button type="submit" name="sbmt" class="btn btn-primary  btn-lg w-25">Save</button>
                    </div>
                    <?php
                    }         
                    ?>
          </form>


<?php


 if(isset($_POST['sbmt']))
 {
  $courseName = $_POST['course'];
  $duration = $_POST['years']." year";
  $q = "INSERT INTO `course`(`course_name`, `duration`) VALUES ('$courseName','$duration')";
  $check = "select * from course where course_name = '$courseName'";
  $r = $conn->query($check);
  $rows = $r->num_rows;
  if($rows>0)
  {
    echo "<div class='alert alert-danger text-center' role='alert'>
    course is already present!
    </div>";    

  }else{
      if(mysqli_query($conn, $q))
      {
        header("Location: course.php");
            exit;
      }else{
        echo "course is not added.";
      }
   }
}
?>


<div class="container mt-5">
<table class="table table-bordered border-dark">
<thead>
    <tr class=" text-center">
      <th scope="col">Course Name</th>
      <th scope="col">Duration</th>
      <th scope="col">Edit</th>
      <th scope="col">Delete</th>
    </tr>
  </thead>
  <tbody>


 

   <?php
 

      // delete course row from table
    //   if (isset($_POST['delete'])) {
    //     $courseToDelete = $_POST['delete'];
    //     $query = "DELETE FROM course WHERE course_name = '$courseToDelete'";
    //     mysqli_query($conn,$query);
    // }



      // Table row
       $q = "select * from course ORDER BY course_name ASC";
       $r = mysqli_query($conn,$q);

       if(mysqli_num_rows($r)>0)
       {
      
        while($rows = mysqli_fetch_assoc($r))
        {
           
          echo "<tr class='text-center'>";
          echo "<td class='text-uppercase'>" . $rows['course_name'] . "</td>";
          echo "<td>" . $rows['duration'] . "</td>";
          echo  "<td><a href='?action=edit&course_name=".$rows['course_name']."'><i class='fas fa-fw fa-edit'></i></a></td>";
          echo  "<td><a href='?action=delete&course_name=".$rows['course_name']."'><i class='fas fa-fw fa-trash'></i></a></td>";     
       // echo "<td><form method='post'><button class='btn btn-secondary' type='submit' name='delete' value='" . $row['course_name'] . "'>Delete</button></form></td>";
          echo "</tr>";          
         }

       }else{   
        echo "<p class='text-danger'>No record found*</p>";
      }         

   ?>

  </tbody>
</table>
</div>





<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>