<?php 
include '../include/dbcon.php';
include '../include/session.php';
error_reporting(0);


//-----Delete----//
if(isset($_GET['id']) && isset($_GET['action']) && $_GET['action'] == 'delete' )
{
       $id = $_GET['id'];
        $query = "DELETE FROM student WHERE ID = '$id'";
        $query2 = "DELETE FROM attendance WHERE ID = '$id'";
        mysqli_query($conn,$query);
        mysqli_query($conn,$query2);
        if ($query) {
             
          echo "<script type = \"text/javascript\">
          window.location = (\"student.php\")
          </script>"; 
          // echo "<div class='alert alert-success text-center'>Student Record deleted successfully.!</div>";
      }
      else
      {
          echo "<div class='alert alert-danger' style='margin-right:700px;'>An error Occurred!</div>";
      }
}

//----Edit-----//

if(isset($_GET['id']) && isset($_GET['action']) && $_GET['action'] == 'edit' )
{
  $id = $_GET['id'];
    $query=mysqli_query($conn,"select * from student where id ='$id'");
        $row=mysqli_fetch_array($query);



        
        if(isset($_POST['update'])){
    
          $fname = $_POST['fname'];
          $lname = $_POST['lname'];
          $email = $_POST['email'];
          $pass = md5($_POST['password']);
          $city = $_POST['city'];
          $phoneNo = $_POST['phoneNo'];
          $course = $_POST['course'];
          $year = $_POST['year'];

            $query=mysqli_query($conn,"update student set fname='$fname', lname='$lname', email='$email', password='$pass',course='$course', year='$year',city='$city',phone='$phoneNo' where id='$id'");

         if ($query) {
             
          echo "<script>alert('Data updated successfully.')</script>";
          
             echo "<script type = \"text/javascript\">
             window.location = (\"student.php\")
             </script>"; 
         }
         else
         {
            echo "<div class='alert alert-danger' style='margin-right:700px;'>An error Occurred!</div>";
         }
     }

}




?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin : Add Student</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" >
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        .list{
            border-radius:5px;
            font-size:15px;
            padding:10px 20px;
            width:50%;
           margin: 0 auto;
        }
        @media screen and (max-width:400px) {
          .list{
            width: 100%;
          }
        }
    
        
    </style>
</head>
<body>
    
<?php include '..\include\header.php'; ?>


 <div class="cotainer p-5">
<form  method="post" class="row g-3" >
  <div class="col-md-6">
    <label for="inputName" class="form-label">First Name</label>
    <input type="text" class="form-control text-capitalize" value="<?php if(isset($_GET['id'])){echo $row['fname'];}  ?>" id="firstName" name="fname" autocomplete="off" required>
  </div>
  <div class="col-md-6">
    <label for="inputName" class="form-label">Last Name</label>
    <input type="text" class="form-control text-capitalize" value="<?php if(isset($_GET['id'])){echo $row['lname'];}  ?>" id="lastName" name="lname" autocomplete="off" required>
  </div>
  <div class="col-md-6">
    <label for="inputEmail4" class="form-label">Email</label>
    <input type="email" class="form-control" value="<?php if(isset($_GET['id'])){echo $row['email'];}  ?>" id="inputEmail4" name="email" required>
  </div>
  <div class="col-md-6">
    <label for="inputPassword4" class="form-label" >Password</label>
    <input type="password" class="form-control" value="<?php if(isset($_GET['id'])){echo $row['password'];}  ?>" id="inputPassword4" name="password" required>
  </div>   


  <div class="col-md-6">
    <label for="inputCity" class="form-label">City</label>
    <input type="text" class="form-control text-capitalize" value="<?php if(isset($_GET['id'])){echo $row['city'];}  ?>" id="inputCity" name="city" required>
  </div>
  <div class="col-md-6">
    <label for="inputphone" class="form-label">Phone No.</label>
    <input type="number" class="form-control" value="<?php if(isset($_GET['id'])){echo $row['phone'];}  ?>" id="inputPhone" name="phoneNo" required>
  </div>

  <div class="col-md-6">
    <select required class="list text-uppercase" name="course" id="course">
        <option value="">Select Course...</option>
        <?php
    
        $q  = "select * from course";
        $r = mysqli_query($conn, $q);
        if(mysqli_num_rows($r)>0)
        {
            while($row = mysqli_fetch_assoc($r))
            {
                echo "<option value='".$row['course_name']."'>".$row['course_name']."</option>";
            }
        }

    ?>
    </select>
   </div>  

        
  <div class="col-md-6">
    <select required class="list text-uppercase" name="year">
        <option value="">Select Year...</option>
        <?php
    
        $q  = "select * from course_year";
        $r = mysqli_query($conn, $q);
        if(mysqli_num_rows($r)>0)
        {
            while($row = mysqli_fetch_assoc($r))
            {
                echo "<option class='text-uppercase' value='".$row['year']."'>".$row['year']."</option>";
            }
        }

   

    ?>
    </select>
   </div>  
    


   <?php
  if (isset($id))
  {
    ?>
       <div class="col-12 text-center my-5">
       <button type="submit" name="update" class="btn btn-warning  btn-lg col-4 col-xs-4">Update</button>
       </div>
       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <?php
  } else {           
    ?>  
        <div class="col-12 text-center my-5">
        <button type="submit" name="sbmt" class="btn btn-primary  btn-lg col-4 col-xs-4">Add Student</button>
        </div>
    <?php
     }         
     ?>

  <!-- <div class="container text-center mt-5">
    <button type="submit" class="btn btn-primary btn-lg col-4 col-xs-4" name="sbmt">Add Student</button>
  </div> -->
</form>
</div>


<?php
    if(isset($_POST['sbmt']))
    {

    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $pass = md5($_POST['password']);
    $city = $_POST['city'];
    $phoneNo = $_POST['phoneNo'];
    $course = $_POST['course'];
    $year = $_POST['year'];


    $checkPass = "select * from student where password='$pass'";
    $checkEmail = "select * from student where email='$email'";
    $p = mysqli_query($conn,$checkPass);
    $e = mysqli_query($conn,$checkEmail);
    $q = "insert into student( fname,lname, email,password,course,year,city,phone) values('$fname','$lname','$email','$pass','$course','$year','$city','$phoneNo')";
    
    if(mysqli_num_rows($p))
    {
      echo "<div class='alert alert-danger text-center col-8 m-auto' role='alert'>
      Password is already taken. Use another password.
      </div>"; 
    }
    else if(mysqli_num_rows($e))
    {
        echo "<div class='alert alert-danger text-center col-8 m-auto' role='alert'>
        This email is already taken. Use another Email.
        </div>"; 
    }
    else{
      if(mysqli_query($conn,$q))
      {
        echo "<div class='alert alert-success text-center col-8 m-auto' role='alert'>
        Student record added successfully.
        </div>"; 
      }else{
        echo "<script>alert('Data is not stored.')</script>";
      }
    }

  

    }

   ?>







 <!-- Table Data -->
 <div class="container my-5">
<table class="table table-responsive table-bordered border-dark ">
<thead>
    <tr class=" text-center">
      <th scope="col">No.</th>
      <th scope="col">Student Name</th>
      <th scope="col">Student ID</th>
      <th scope="col">Course</th>
      <th scope="col">Year</th>
      <th scope="col">Password</th>
      <th scope="col">Edit</th>
      <th scope="col">Delete</th>
    </tr>
  </thead>
  <tbody>



   <?php

      // Table row
       $q = "SELECT * FROM `student` ORDER BY fname ASC ";
       $r = mysqli_query($conn,$q);

       if(mysqli_num_rows($r)>0)
       {
         $no = 1;
        while($row = mysqli_fetch_assoc($r))
        {
           $pass = $row['password'];
          echo "<tr class='text-center'>";
          echo "<td> $no </td>";
          echo "<td class='text-uppercase'>" . $row['fname']."  " .$row['lname'] . "</td>";
          echo "<td class='text-uppercase'>" . $row['ID'] . "</td>";
          echo "<td>" . $row['course'] . "</td>";
          echo "<td>" . $row['year'] . "</td>";
          echo  "<td><a href='https://md5.gromweb.com/?md5=$pass' target='blank'><i class='fa-solid fa-eye-slash'></i></a></td>";
          echo  "<td><a href='?action=edit&id=".$row['ID']."'><i class='fas fa-fw fa-edit'></i></a></td>";
          echo  "<td><a href='?action=delete&id=".$row['ID']."'><i class='fas fa-fw fa-trash'></i></a></td>";  
          // echo "<td><form method='post'><button class='btn btn-secondary' type='submit' name='delete' value='" . $row['ID'] . "'>Delete</button></form></td>";
          echo "</tr>";     
                $no += 1;     
         }

       }else{   
        echo "<p class='text-danger'>No record found*</p>";
      }        

   ?>

  </tbody>
</table>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>