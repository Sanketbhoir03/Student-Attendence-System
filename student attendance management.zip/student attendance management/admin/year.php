<?php 
include '../include/dbcon.php';
include '../include/session.php';
error_reporting(0);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin : Add Year</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include '..\include\header.php'; ?>


<div class="cotainer p-5">
<form method="post" class="d-flex justify-content-center row g-5" autocomplete="off">

  <div class="col-md-6">
    <label for="inputName" class="form-label">year</label>
    <input type="text" class="form-control p-2 text-uppercase" id="inputName" name="year" placeholder="ex -   FY" required>
  </div>

 
  <div class="col-12 text-center my-5">
    <button type="submit" class="btn btn-primary btn-lg w-25" name="sbmt">Add Year</button>
  </div>
</form>


<?php

 if(isset($_POST['sbmt']))
 {
  $year = $_POST['year'];
  $q = "INSERT INTO `course_year`(year) VALUES('$year')";
  $check = "SELECT * FROM course_year WHERE year = '$year'";
  $r = $conn->query($check);
  $num = mysqli_num_rows($r);
  if($num > 0)
  {
    echo "<div class='alert alert-danger' role='alert'>
    Year is already present!
    </div>"; 
  }else{

       if(mysqli_query($conn, $q))
       {
         header("Location: year.php");
             exit;
       }else{
         echo "course is not added.";
       }
   }
 }

?>


<div class="container mt-5">
<table class="table table-bordered border-dark">
<thead>
    <tr class=" text-center">
      <th scope="col">NO.</th>
      <th scope="col">Year</th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody>


   <?php


      // delete course row from table
      if (isset($_POST['delete'])) {
        $courseToDelete = $_POST['delete'];
        $query = "DELETE FROM course_year WHERE num = $courseToDelete";
        mysqli_query($conn,$query);
       }


      // Table row
       $q = "select * from course_year ORDER BY year ASC";
       $r = mysqli_query($conn,$q);

       if(mysqli_num_rows($r)>0)
       {
      
         $no = 1;
        while($row = mysqli_fetch_assoc($r))
        {
          echo "<tr class='text-center'>";
          echo "<td>$no</td>";
          echo "<td class='text-uppercase'>" . $row['year'] . "</td>";
          echo "<td><form method='post'><button class='btn btn-secondary' type='submit' name='delete' value='" . $row['num'] . "'>Delete</button></form></td>";
          echo "</tr>";         
          $no += 1; 
         }

       }else{   
         echo "<p class='text-danger'>No record found*</p>";
       }        

   ?>

  </tbody>
</table>
</div>





<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js" integrity="sha512-16esztaSRplJROstbIIdwX3N97V1+pZvV33ABoG1H2OyTttBxEGkTsoIVsiP1iaTtM8b3+hu2kB6pQ4Clr5yug==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="js\adminPage.js"></script>
</body>
</html>