<?php 
include '../include/dbcon.php';
include '../include/session.php';
error_reporting(0);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin : Add subject</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>
<?php include '..\include\header.php'; ?>



<div class="cotainer p-5">

<form method="post" class="row g-5" autocomplete="off">

<div class="col-md-6">
<label for="inputName" class="form-label">Course Name :</label>
    <select class="form-control list  " name="course" required>
        <option value="null" disabled selected>Select Course...</option>
        <?php
    
    $conn = mysqli_connect("localhost","root","","student_attendance_management");
    if($conn)
    {

        $q  = "select * from course";
        $r = mysqli_query($conn, $q);
        if(mysqli_num_rows($r)>0)
        {
            while($row = mysqli_fetch_assoc($r))
            {
                echo "<option class='text-uppercase' value='".$row['course_name']."'>".$row['course_name']."</option>";
            }
        }

    }else{
        echo "database is not connected";
    }

    ?>
    </select>
   </div> 

  <div class="col-md-6">
    <label for="inputName" class="form-label">Subject Name :</label>
    <input type="text" class="form-control text-uppercase" id="inputName" name="subject" required>
  </div>


 
  <div class="col-12 text-center my-5">
    <button type="submit" class="btn btn-primary btn-lg w-25" name="sbmt">Add subject</button>
  </div>
</form>


<?php

$conn = mysqli_connect("localhost","root","","student_attendance_management");
if($conn)
{

  

 if(isset($_POST['sbmt']))
 {

  if(!empty($_POST['course']) && $_POST['subject'])
  {
    $courseName = $_POST['course'];
    $subjectName = $_POST['subject'];
    $q1 = "select * from subjects where course_name='$courseName' && subject_name='$subjectName'";
    $check = mysqli_query($conn, $q1);
    $q = "insert into subjects(course_name,subject_name) values('$courseName','$subjectName')";
   
    if(mysqli_num_rows($check)>0)
    {
        echo "<script>alert('Subject is already present.')</script>";
    }else{
      if(mysqli_query($conn, $q))
      {
        header("Location: subjects.php");
            exit;
      }else{
        echo "course is not added.";
      }
    }

  }

 }
}else{
  echo "Data is not inseted. Database is not connected.";
}
?>



<div class="container mt-5">
<table class="table table-bordered border-dark">
<thead>
    <tr class=" text-center">
      <th scope="col">Course Name</th>
      <th scope="col">Subject</th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody>


 

   <?php
     $conn = mysqli_connect("localhost","root","","student_attendance_management");
     if($conn)
     {

      // delete course row from table
      if (isset($_POST['delete'])) {
        $subToDelete = $_POST['delete'];
        $query = "DELETE FROM subjects WHERE id = $subToDelete";
        mysqli_query($conn,$query);
    }


      // Table row
       $q = "select * from subjects ORDER BY course_name ASC";
       $r = mysqli_query($conn,$q);

       if(mysqli_num_rows($r)>0)
       {
      
        while($row = mysqli_fetch_assoc($r))
        {
           
          echo "<tr class='text-center'>";
          echo "<td class='text-uppercase'>" . $row['course_name'] . "</td>";
          echo "<td class='text-uppercase'>" . $row['subject_name'] . "</td>";
          echo "<td><form method='post'><button class='btn btn-secondary' type='submit' name='delete' value='" . $row['id'] . "'>Delete</button></form></td>";
          echo "</tr>";          
         }

       }else{   
        echo "<p class='text-danger'>No record found*</p>";
      }       


     }else{
        echo "Database is not connected.";
     }
   ?>

  </tbody>
</table>
</div>





<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>