<?php
   include 'include\dbcon.php';


  session_start();
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login Page</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <style>
      *{
        margin: 0;
        padding: 0;
        box-sizing:border-box;
        font-family:"monospice";
      }
      body{
        height:100vh;
      }
       .container{
        border-radius: 10px;
        padding: 110px 50px;
        transition: all .3s ease-in-out;
      }
      .container:hover{
         box-shadow: 5px 5px 25px rgba(0,0,0, 0.5);
       }
      .title span{
        display: inline-block;
        font-size:50px;
        text-shadow: 6px 1px 5px grey;
        position: relative;
        background-color: #fff;
      
      }
      .title span::after{
        content: "";
        display: block;
        border-bottom: 5px solid  #343a40;
        transform: scaleX(0);
        transition: transform 300ms ease-in-out;
      }

      .title span:hover::after{
        transform: scaleX(1);
      }

      .user:hover, .input:hover, .btn:hover{
        box-shadow: 5px 5px 7px 0px #0000003f;
      }
      
      .alert-danger{
        background-color: lightcoral;
        color: #fff;
        width: 100%;
      }


     #btn1 {
    background-color: #343a40;
    color: #fff;
    padding: 0.8rem 2.3rem;
    font-size: 18px;
    box-shadow: 5px 5px 7px 0px #0000003f;
    position: relative;
    z-index: 1;
    text-transform: uppercase;
}


  #btn1::after{
    content:'';
    display: block;
    position: absolute;
    height: 100%;
    width: 100%;
    left: 0;
    top: 0;
    background-color: #fff;
    transform: scaleX(0);
    z-index: -1;
    transition: transform .5s ease-in-out;
  }
  #btn1:hover::after{
    transform: scaleX(1);
  }
  #btn1:hover{
  color: black;
} 

      @media screen and (max-width: 550px) {
        nav img{
          width: 70%;
          height: 80%;
        }
      }
      @media screen and (max-width: 400px) {
        nav img{
          width: 80%;
          height: 80%;
        }
      }
    </style>
  </head> 
  <body>


<nav class="nav bg-dark">
  <h2 class="mx-auto my-5 text-light">Sahyog College</h2>
  <!-- <img class="mx-auto my-5" src="https://sahyogcollege.com/themes/demo/assets/images/logo.png" alt="Sahyog College"> -->
</nav>
  
  <div class="container mt-5">
  
  <form action="" method="post" class="form w-100" id="loginForm">
  <div class="mb-3">
    <h3 class="title text-center mb-5"><span>Login</span></h3>

    <div class="inputs">
    <label  class="form-label"> User</label>
    <div class="form-group user">
            <select required class="form-control" id="dropdown" name="user">
                <option value="">---Select User Role---</option>
                <option value="admin">Administrator</option>
                <option value="teacher">Teacher</option>
                <option value="student">Student</option>
            </select>
        </div>



      <label for="exampleInputEmail1" class="form-label">Email address</label>
      <input type="email" class="form-control input" id="exampleInputEmail1" name="email" aria-describedby="emailHelp" required>


   
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <input type="password" class="form-control  input" name="password" id="exampleInputPassword1" required>
  </div>


  <!-- <button type="submit" class="btn btn-primary w-100 mt-3" name="sbmt">Submit</button> -->
  <button type="submit" class="btn w-100 mt-3" id="btn1" name="sbmt">Submit</button>
  </div>
</form>
</div>
<?php
    if($conn)
    {
     
      if(isset($_POST['sbmt']))
      {

        $user = $_POST['user'];
        $email = $_POST['email'];
        $pass = md5($_POST['password']);
        $admin = "admin";
        $teacher = "teacher";
        $student = "student";

        $q = "select * from $user where email='$email' AND password='$pass'";
   
        $r = mysqli_query($conn ,$q);
        $rws = mysqli_num_rows($r);
         $row = mysqli_fetch_assoc($r);
          if($rws>0)  
          {
                        
                 if($user==$admin)
                 {
                  $_SESSION["user"] = $user;
                  $_SESSION["id"] = $row['ID'];
                  $_SESSION["fName"] =  $row['fname'];
                  $_SESSION["lName"] = $row['lname'];
                  $_SESSION["email"] = $row['email'];
                  echo "<script> window.location.href= 'http://localhost/php/student%20attendance%20management/admin/admin.php';</script>";
                  // header("Location: http://localhost/php/student%20attendance%20management/admin/admin.php");
               
                 }else if($user==$teacher){
                  $_SESSION["user"] = $user;
                  $_SESSION["id"] = $row['ID'];
                  $_SESSION["fName"] =  $row['fname'];
                  $_SESSION["lName"] = $row['lname'];
                  $_SESSION["email"] = $row['email'];              
                  $_SESSION["class"] = $row['class'];              
                  $_SESSION["year"] = $row['year'];              
                  echo "<script> window.location.href= 'http://localhost/php/student%20attendance%20management/teacher/home.php';</script>";
                  // header("Location: http://localhost/php/student%20attendance%20management/teacher/home.php");

                }else if($user==$student){
                  $_SESSION["user"] = $user;
                  $_SESSION["id"] = $row['ID'];
                  $_SESSION["fname"] =  $row['fname'];
                  $_SESSION["lname"] = $row['lname'];
                  $_SESSION["email"] = $row['email'];              
                  $_SESSION["class"] = $row['course'];              
                  $_SESSION["year"] = $row['year'];         
                  echo "<script> window.location.href= 'http://localhost/php/student%20attendance%20management/student/home.php';</script>";
                  // header("Location: http://localhost/php/student%20attendance%20management/student/home.php");

                 }
             
                     
    
          }else{
            // echo "<div class='container mt-5'>
            //       <div class='alert alert-danger text-center' role='alert'>
            //        Invalid Username/Password!
            //        </div>
            //       </div>";

            echo "<script>alert('Invalid Username/Password!')</script>";
            }

      }

    }else{
      echo "<script>alert('database is not connected')</script>";
    }

?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js" integrity="sha512-16esztaSRplJROstbIIdwX3N97V1+pZvV33ABoG1H2OyTttBxEGkTsoIVsiP1iaTtM8b3+hu2kB6pQ4Clr5yug==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="js/loginPage.js"></script>
</body>
</html>




