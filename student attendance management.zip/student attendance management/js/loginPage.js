//login Page 

  var tl = gsap.timeline();

  tl.from(".nav",{
      y:-20,
      opacity:0,
      delay:.5,
    duration: .5,

  })
  tl.from(".container h3",{
    y:-20,
    opacity:0,
  duration: .5,

  })
  tl.from(".container .inputs",{
    opacity:0,
    duration:.5  
  })


