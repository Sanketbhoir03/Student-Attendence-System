

gsap.from('.container',{
    y:20,
    duration:3
})