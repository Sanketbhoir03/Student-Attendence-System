<?php
include '../include/dbcon.php';
include '../include/session.php';
error_reporting(0);


$todaysDate =  date("d-m-Y");
// print_r($_SESSION);
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Teacher panel : Attendance</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    *{
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
  .check {
    height: 30px;
    width: 30px;
  }
  </style>

</head>
<body>
  <?php include '..\include\teacherHeader.php'; ?>



  <div class="container-fluid my-5" id="container-wrapper">
    <h1 class="h3 text-gray-800 ps-5">Take Attendance (Today's Date : <?php echo $todaysDate ?>)</h1>
  </div>
  <div class="mx-5 py-3 d-flex flex-row align-items-center justify-content-between">
    <h6 class="font-weight-bold text-primary">All Student in (<?php echo $_SESSION['class'] . ' - ' . $_SESSION['year']; ?>) Class</h6>
    <h6 class="font-weight-bold text-danger">Note: <i>Click on the checkboxes besides each student to take attendance!</i></h6>
  </div>

  <div class="container my-5">
    <form method="post">
      <table class="table table-bordered border-dark">
        <thead>
          <tr class=" text-center">
            <th scope="col">NO.</th>
            <th scope="col">Student Name</th>
            <th scope="col">check</th>
          </tr>
        </thead>
        <tbody>
          <?php

          $class = $_SESSION['class'];
          $year = $_SESSION['year'];

          // Table row
          $q = "select * from student where course = '$class' AND year ='$year' order by fname asc";
          $r = mysqli_query($conn, $q);

          if (mysqli_num_rows($r) > 0) {
            $no = 1;
            while ($row = mysqli_fetch_assoc($r)) {

              echo "<tr class='text-center'>";
              echo "<td class='pt-3'>$no</td>";
              echo "<td  class='pt-3 text-uppercase'>" . $row['fname'] . " " . $row['lname'] . "</td>";
              // echo "<td><button class='btn btn-success m-1'  name='present' value='" . $row['ID'] . "'>Present</button><button class='btn btn-danger m-1' ' name='absent' value='" . $row['ID'] . "'>Absent</button></td>";
              echo "<td><input class='form-check-input check' type='checkbox' name='check[]' value='" . $row['ID'] . "' id='flexCheckDefault'></td>";
              echo "<input type='hidden' name='IDs[]' value='" . $row['ID'] . "'>";
              echo "</tr>";
              $no += 1;
            }
          }


          ?>
        </tbody>
      </table>


      <div class="text-center">
        <input type="submit" name="presenty" class="col-md-4 btn btn-success my-5" value='Take Attendancy'>
      </div>
    </form>
  </div>

  

  <?php
  if (isset($_POST['presenty'])) 
  {

    $check = "select * from attendance where date = '$todaysDate' AND course='$class' AND year='$year'";     // AND status ='present'
    $r = $conn->query($check);
    if (mysqli_num_rows($r) > 0)
     {
      echo "<div class='alert alert-danger text-center  w-50 m-auto' role='alert'>
        Attendance has been already taken for today!
      </div>";
        }else
        {
           $check = "" ;
           if(isset($_POST['check']))
           {
             $check =   $_POST['check'];
             $checkLength =  count($check);
           }
           $IDs =   $_POST['IDs'];
           $listLength =  count($IDs);
          //  print_r($check);
           if($listLength > 0 && $check!=null)
           {
               $q1 = "select * from student where course = '$class' AND year ='$year' order by fname asc";
               $r = mysqli_query($conn, $q1);
               while($rws = $r->fetch_assoc())
               {
                  $ID = $rws['ID'];
                  $fname = $rws['fname'];
                  $lname = $rws['lname'];
                  $course = $rws['course'];
                  // $year = $rws['year'];
                  $q2 = "INSERT INTO `attendance` VALUES ('$ID','$fname','$lname','$course','$year','$todaysDate','absent')";
                  mysqli_query($conn,$q2);
                }

                 for($i = 0; $i<$listLength; $i++)
                 {
                    if(isset($check[$i]))
                    {
                      $checked = $check[$i];
                      $q3 = "UPDATE `attendance` SET  status='present' WHERE ID ='$checked' ";
                      mysqli_query($conn,$q3);
                    }
                 }
                 echo "<div class='alert alert-success text-center  w-50 m-auto' role='alert'>
                 Attendance is successfully saved!
               </div>";

           }else{
            echo "<div class='alert alert-danger text-center  w-50 m-auto' role='alert'>
                   0 students present! 
                  </div>";
            
           }


    }
  }

  ?>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>