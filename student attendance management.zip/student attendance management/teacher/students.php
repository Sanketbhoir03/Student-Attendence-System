
<?php
include '../include/dbcon.php';
include '../include/session.php';
error_reporting(0);


$todaysDate =  date("d-m-Y");
// print_r($_SESSION);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Panel : students</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Edu+SA+Beginner:wght@600&family=Shadows+Into+Light&display=swap" rel="stylesheet">
  <style>
    .heading{
        font-family: 'Shadows Into Light', cursive;
        font-weight: 600;
    }
  </style>
</head>
<body>
  <?php include '..\include\teacherHeader.php'; ?>
    
  <div class="container">
    <?php 
       $class = $_SESSION["class"];              
       $year = $_SESSION["year"];
        echo "<h1 class=' heading text-uppercase p-5'><i>All students in ($year$class)</i></h1>";


        $q ="select * from student where course = '$class' AND year = '$year' order by fname asc";
        $r = $conn->query($q);
        if($r->num_rows > 0)
        {
             echo "<table class='table table-bordered border-dark'>
                   <thead>
                   <tr class=' text-center'>
                     <th scope='col'>NO.</th>
                     <th scope='col'>Student Name</th>
                     <th scope='col'>Student ID</th>
                   </tr>
                 </thead>
                 <tbody>";
                 $no =1;
            while($row = $r->fetch_assoc())
            {
                $fname = $row['fname'];
                $lname = $row['lname'];
                $id = $row['ID'];

                echo "<tr class='text-center'>
                       <td>$no</td>
                        <td class='text-uppercase'>$fname $lname</td>
                         <td>$id</td>";
                
                $no +=1;       
            }
                 echo " </tbody>
                  </table>";
        }else{
            echo "<div class='alert alert-danger text-center  w-50 m-auto' role='alert'>
            No record found! 
           </div>";
        }
    ?>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>