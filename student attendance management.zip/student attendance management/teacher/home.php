<?php
include '../include/dbcon.php';
include '../include/session.php';
error_reporting(0);


$todaysDate =  date("d-m-Y");
// print_r($_SESSION);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Panel : Home page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Abril+Fatface&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  
      <style>
        *{
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }
        body, html{
          width: 100%;
          height: 100%;
        }
      .heading{
        font-family: 'Prata', serif;       
         }
  </style>
</head>
<body>

<?php include '..\include\teacherHeader.php'; ?>

    
  <div class="main my-5">
    <div class="col-12">
  <?php 
       $class = $_SESSION["class"];              
       $year = $_SESSION["year"];
        echo "<h1 class=' heading text-gray-900 text-uppercase p-5'><i>Class Teacher Dashboard ($year$class)</i></h1>";
    ?>
   </div>

   <div class="row m-5 align-items-center justify-content-around gap-5">
       <div class="col-lg-4 col-md-12 col-12 my-5 bg-secondary text-light rounded px-3 py-4 d-flex align-items-center justify-content-between">
            <div class="col-auto">  
              <div class="col-xs mb-3 font-weight-bold text-uppercase">Total class  Students</div> 
              <?php 
               $q1 = "select * from student where course = '$class' AND year = '$year'";
              //  $r = $conn->query($q1);
               $r = mysqli_query($conn, $q1);
               $rows = $r->num_rows;
               echo "<div class='h4 text-center font-weight-bold'>$rows</div>" ;
              ?>
              </div>
              <div class="col-auto">
              <i class="fa-solid fa-2xl fa-users fa-bounce"></i> 
               </div>
       </div>

       <div class="col-lg-4 col-md-6 col-12 my-5 text-centr">
       <?php
         $todaysDate = date("d-m-Y");
        $q = "select * from attendance where date='$todaysDate' AND course='$class' AND year='$year'";
        $r = $conn->query($q);
        $num = $r->num_rows;
        if($num > 0)
        {
          echo "<div class='h5 mt-5 me-5 text-end'>Note : <span class='h6 text-danger'><i>Todays attendance has been taken already!</i></span></div>";

        }else{
          echo "<div class='h5 mt-5 me-5 text-end'>Note : <span class='h6 text-danger'><i>today's attendance has not be taken!</i></span></div>";
        }
      ?>
       </div>
     
   </div>

  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>