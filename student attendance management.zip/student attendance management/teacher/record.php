<?php 
include '../include/dbcon.php';
include '../include/session.php';
error_reporting(0);


$todaysDate = date("d-m-Y");
$class = $_SESSION['class'];
$year = $_SESSION['year'];
// print_r($_SESSION);
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Teacher Panel : Record</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      user-select: none;
    }
    .heading h1{
      /* color: transparent; */
      color: grey;
      font-size: 3.5vw;
      font-weight: 700;
      -webkit-text-stroke: 2px #000;
      text-shadow:15px 10px 10px grey;
      
    }
    .heading .det{
      font-size: 20px;
    }
    @media screen and (max-width:700px) {
      .heading h1{
        font-size: 7vw;
      }
    }
    @media screen and (max-width:400px) {
      .heading h1{
        font-size: 10vw;
      }
    }
  </style>
</head>

<body>

<?php include '..\include\teacherHeader.php'; ?>

 <div class="wrapper heading pb-5 text-uppercase" >
    <h1 class=" text-center">Attendance Record <?php echo "($year$class)"; ?></h1>
 </div>

 <!-- <div class="container d-flex justify-content-end" >
   <form  method="post"></form>
   <a href="export.php"><button class="bg-primary px-2 py-1 rounded">Export</button>
   </a>
</div> -->

   <div class="container my-5">
    <div class="row">
      <div class="col-lg-6 my-2">
       <form method="post" class="w-100 d-flex gap-4">
       <select required class="form-select w-50" name='seloption' aria-label="Default select example">
  <option value="">Search by...</option>
  <option value="name">Name</option>
  <option value="date">Date</option>
  <option value="id">id</option>
  <option value="status">Status</option>
</select>
       <input type="submit" class="btn btn-info" value="List" name='list'>
       </div>
       </form>
   



   <?php
    if(isset($_POST['list']))
    {
      //sessions 
      $class = $_SESSION['class'];
      $year = $_SESSION['year'];


      $option = $_POST['seloption'];
      if($option=='name')
      {
         $q = "select * from student where course = '$class' and year = '$year' order by fname asc";
         $r = $conn->query($q);
          if($r->num_rows > 0)
          {
              echo " 
              <div class='col-lg-6 my-2'>
              <form method='post' class='d-flex gap-4'>
                 <select required class='form-select w-50' name='id' aria-label='Default select example'>
            <option value=''>Search by...</option>";
              while($row = $r->fetch_assoc())
              {
                $fname = $row['fname'];
                $lname = $row['lname'];
                $id = $row['ID'];

                echo "   <option value='$id'>$fname $lname</option> ";
                
              }

              echo "   </select>
                     <input type='submit' class='btn btn-info' value='Search' name='search'>
                    </div>
                   </form>
                 </div'";
          }else{
            echo "<div class='alert alert-secondary text-center  w-50 m-auto' role='alert'>
               No record found!
                </div>";
            }
       }else if($option == 'date')
       {
        echo " 
              <div class='col-lg-6 my-2'>
              <form method='post' class='d-flex gap-4'>
              <input type='text' name='date' placeholder='DD-MM-YYYY' value='$todaysDate' required>
              <input type='submit' class='btn btn-info' value='Search' name='search'>
              </div>
             </form>";
       }else if($option == 'id')
       {
        echo " 
        <div class='col-lg-6 my-2'>
        <form method='post' class='d-flex gap-4'>
        <input type='text' name='id' required>
        <input type='submit' class='btn btn-info' value='Search' name='search'>
        </div>
       </form>";
       }else if($option == 'status')
       {
        echo " 
        <div class='col-lg-6 my-2'>
        <form method='post' class='w-100 d-flex gap-4'>
        <select required name='status' class='form-select w-50' aria-label='Default select example'>
        <option value=''>select status...</option>
        <option value='present'>Present</option>
        <option value='absent'>Absent</option>
      </select>
        <input type='submit' class='btn btn-info' value='Search' name='search'>
        </div>
        </form>";
       }
    }
   ?>
   </div>
</div>



<div class='container my-5'>
<table class='table table-responsive table-bordered border-dark '>
<thead>
    <tr class='text-center'>
      <th scope='col'>No.</th>
      <th scope='col'>Student Name</th>
      <th scope='col'>Date</th>
      <th scope='col'>Status</th>
    </tr>
  </thead>
  <tbody> 
    
    <?php
      if(isset($_POST['search']))
      {  
           //sessions 
           $class = $_SESSION['class'];
           $year = $_SESSION['year'];

        $q1 = "select * from attendance where course = '$class' and year = '$year' and ";
        if(isset($_POST['id']))
        {
             
          $id = $_POST['id'];
          $q2 = "ID = $id";
          $r = $conn->query($q1.$q2);
          if($r->num_rows >0)
          {
          $no = 1;
          while ($row=$r -> fetch_array())
          {
            $html = " <tr>
                      <td>$no</td>
                      <td>".$row['fname']." ".$row['lname']."</td>
                      <td>".$row['date']."</td>
                      <td>".$row['status']."</td>
                      </tr> " ;
                      echo "$html" ;
                      $no++;
           }
          }else{
            echo "<div class='alert alert-danger text-center  w-50 m-auto mb-5' role='alert'>
                  No record found!
                   </div>";
          }
        }else if(isset($_POST['date']))
        {
          $date = $_POST['date'];
          
        $q = "select * from attendance where course = '$class' and year = '$year' and date='$date'";
          $r = $conn->query($q);
          if($r->num_rows >0)
          {
            $no = 1;
            while ($row=$r -> fetch_array())
            {
              $html = " <tr>
                        <td>$no</td>
                        <td>".$row['fname']." ".$row['lname']."</td>
                        <td>".$row['date']."</td>
                        <td>".$row['status']."</td>
                        </tr> " ;
                        echo "$html" ;
                        $no++;
             }
          }else{
            echo "<div class='alert alert-danger text-center  w-50 m-auto mb-5' role='alert'>
                  No record found!
                   </div>";
          }
        }else if(isset($_POST['id']))
        {
          $id = $_POST['id'];
          $q = "select * from attendance where course = '$class' and year = '$year' and id='$id'";
          $r = $conn->query($q);
          if($r->num_rows >0)
          {
            $no = 1;
            while ($row=$r -> fetch_array())
            {
              $html = " <tr>
                        <td>$no</td>
                        <td>".$row['fname']." ".$row['lname']."</td>
                        <td>".$row['date']."</td>
                        <td>".$row['status']."</td>
                        </tr> " ;
                        echo "$html" ;
                        $no++;

           }
         }
        }else if(isset($_POST['status']))
        {
          $status = $_POST['status'];
          $q = "select * from attendance where course = '$class' and year = '$year' and status='$status'";
          $r = $conn->query($q);
          if($r->num_rows >0)
          {
            $no = 1;
            while ($row=$r -> fetch_array())
            {
              $html = " <tr>
                        <td>$no</td>
                        <td>".$row['fname']." ".$row['lname']."</td>
                        <td>".$row['date']."</td>
                        <td>".$row['status']."</td>
                        </tr> " ;
                        echo "$html" ;
                        $no++;

                 }
             }
        }
      }
    ?>

 </tbody>
</table>
</div>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>