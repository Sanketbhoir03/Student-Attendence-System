<?php
include '../include/dbcon.php';
include '../include/session.php';
error_reporting(0);

 
$todaysDate = date("d-m-Y");
$class = $_SESSION['class'];
$year = $_SESSION['year'];

$q = "select * from attendance where course = '$class' and year='$year' and date = '$todaysDate' ";
$r = $conn->query($q);
$html = " <table class='table table-responsive table-bordered border-dark'>
         <thead>
             <tr class='text-center'>
               <th scope='col'>No.</th>
               <th scope='col'>Student Name</th>
               <th scope='col'>Date</th>
               <th scope='col'>Status</th>
             </tr>
           </thead>
           <tbody> ";
if($r->num_rows > 0)
{      $no =1;
    while($row = $r->fetch_assoc())
    {
        $html.= "<tr>
        <td>$no</td>
        <td>".$row['fname']." ".$row['lname']."</td>
        <td>".$row['date']."</td>
        <td>".$row['status']."</td>
        </tr>" ;
        $no++;
    }
    $html.="  </tbody> </table>";

    
    header('Content-Type:application/xls');
    header('Content-Disposition:attachment; filename='.$todaysDate.'/Report.xls ');
    echo $html;
}else{

    echo "
    <!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Report</title>
  <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css' rel='stylesheet'>
    
</head>
<body>
 
</body>
</html>

    <div class='alert alert-danger text-center  w-50 m-auto my-5' role='alert'>
    May be todays attendance has not been taken!
     </div>;

   <div class='container'>
              <a href='../teacher\home.php'><button class='btn-secondary rounded px-2 py-1'>&#8592;Back</button></a>
               </div>";
      }

?>
