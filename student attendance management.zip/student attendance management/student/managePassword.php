<?php
include '../include/dbcon.php';
include '../include/session.php';
error_reporting(0);


$todaysDate =  date("d-m-Y");
$month =  date("m");
$curryear =  date("Y");
$class = $_SESSION["class"];              
$year = $_SESSION["year"];
$fname = $_SESSION["fname"];
$lname = $_SESSION["lname"];
$id = $_SESSION["id"];
// print_r($_SESSION);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Panel : Manage Password</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Abril+Fatface&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

</head>
<body>

<?php include '..\include\studentHeader.php'; ?>

<div class="container  mt-3 text-center">
    <p>Click on the button to change Email and password of Admin.</p>

    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal">
      Change
    </button>
  </div>

  <!-- The Modal -->
  <div class="modal" id="myModal">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Admin</h4>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
          <form method="post">
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label">Email address</label>
              <input required type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email">
            </div>
            <div class="mb-3">
              <label for="exampleInputPassword1" class="form-label">Password</label>
              <input required type="password" class="form-control" id="exampleInputPassword1" name="password">
            </div>
            <div class="mb-3">
              <label for="exampleInputPassword1" class="form-label">Confirm Password</label>
              <input required type="password" class="form-control" id="exampleInputPassword1" name="conPassword">
              <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
            </div>
            <button type="submit" class="btn btn-primary" name="submit">Submit</button>
          </form>
        </div>

        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
        </div>

      </div>
    </div>
  </div>


  <?php

    if (isset($_POST['submit'])) 
    {

      if($_POST['email'] && $_POST['password'] && $_POST['conPassword'])
      {
        $email = $_POST['email'];
        $pass = md5($_POST['password']);
        $cpass = md5($_POST['conPassword']);
        $q = "UPDATE `student` SET `email`='$email',`password`='$pass' where ID='$id'";
        if ($pass === $cpass) 
        {
            if(mysqli_query($conn,$q))
            {
               echo "<script>alert('Email & Password is changed.')</script>";
               header("Location: http://localhost/php/student%20attendance%20management/index.php");
            }else{
              echo "<script>alert('Email & Password is not changed.')</script>";
            }
        } else {
          echo "<script>alert('Passwords not matched.')</script>";
        }
      }
 
    }
  ?>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>