<?php
include '../include/dbcon.php';
include '../include/session.php';
error_reporting(0);

 
$todaysDate =  date("d-m-Y");
$currMonth =  date("m");
$currYear =  date("Y");
$class = $_SESSION["class"];
$year = $_SESSION["year"];
$fname = $_SESSION["fname"];
$lname = $_SESSION["lname"];
$id = $_SESSION["id"];

$q = "select * from attendance where ID = '$id' and date between '01-$currMonth-$currYear' AND '$todaysDate'";
$r = $conn->query($q);
$html = " <table class='table table-responsive table-bordered border-dark'>
         <thead>
             <tr class='text-center'>
               <th scope='col'>No.</th>
               <th scope='col'>Student Name</th>
               <th scope='col'>Date</th>
               <th scope='col'>Status</th>
             </tr>
           </thead>
           <tbody> ";
if($r->num_rows > 0)
{      $no =1;
    while($row = $r->fetch_assoc())
    {
        $html.= "<tr>
        <td>$no</td>
        <td>".$row['fname']." ".$row['lname']."</td>
        <td>".$row['date']."</td>
        <td>".$row['status']."</td>
        </tr>" ;
        $no++;
    }
    $html.="  </tbody> </table>";

    
    header('Content-Type:application/xls');
    header('Content-Disposition:attachment; filename=AttendanceReport.xls');
    echo $html;
}

?>
