<?php
include '../include/dbcon.php';
include '../include/session.php';
error_reporting(0);


$todaysDate =  date("d-m-Y");
$currMonth =  date("m");
$currYear =  date("Y");
$class = $_SESSION["class"];
$year = $_SESSION["year"];
$fname = $_SESSION["fname"];
$lname = $_SESSION["lname"];
$id = $_SESSION["id"];
// print_r($_SESSION);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Panel : Record</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Abril+Fatface&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

</head>

<body>

    <?php include '..\include\studentHeader.php'; ?>

    <div class="container">
        <?php
          $q = "select * from attendance where ID = '$id' and date between '01-$currMonth-$currYear' AND '$todaysDate'";
          $r = $conn->query($q);
          if($r->num_rows > 0)
          {
            echo "<div class='d-flex justify-content-end my-5'>
                    <a href='report.php'><button class='bg-primary rounded text-light px-3 py-1'>Export</button></a>     
                    </div>";
            $no = 1;
            $html = " <table class='table table-responsive table-bordered border-dark'>
                     <thead>
                    <tr class='text-center'>
                      <th scope='col'>No.</th>
                      <th scope='col'>Student Name</th>
                      <th scope='col'>Date</th>
                      <th scope='col'>Status</th>
                    </tr>
                  </thead>
                  <tbody> ";
                  
                  while ($row=$r->fetch_assoc())
                  {
                    $html.= "<tr>
                      <td>$no</td>
                      <td>".$row['fname']." ".$row['lname']."</td>
                      <td>".$row['date']."</td>
                      <td>".$row['status']."</td>
                      </tr>" ;
                      $no++;
                  }
               $html.="  </tbody> </table>";
             echo $html;
          }else{
            echo "<div class='alert alert-danger text-center  w-50 m-auto' role='alert'>
            No record found!
          </div>";
          }
        ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>