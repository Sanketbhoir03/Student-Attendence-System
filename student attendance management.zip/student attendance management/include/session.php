<?php
  session_start();
  if(!isset($_SESSION['user']))
  {
    header("Location: http://localhost/php/student%20attendance%20management/index.php");
  }
?>