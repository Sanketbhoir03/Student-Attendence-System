<?php 
$host = "localhost";
$user = "root";
$pass = "";
$db = "student_attendance_management";

$conn = mysqli_connect($host,$user,$pass,$db);
if($conn->connect_error)
{
    echo "Failed to connect database".$conn->connect_error;
}
?>